# Selected candidate: mybot

Source: src/mybot/RobotPlayer.java. Independently authored local Battlecode 2023 bot.
Selected verified build: ../work/standoff-build.
Source package: ../work/selected-package/source.zip (metadata package.json).
Final report: ../work/final-report.md.
Initial plan: ../work/initial-plan.md.
Experiment preregistration and source diff: ../work/experiments/001-preregistered.md and 001-change.diff.
Reproduction commands and all eight active-opponent evidence records are under ../work/.

The candidate won 4/4 local paired retests against the pinned official lecture bot; baseline also won 4/4. This is a two-map, one-educational-opponent diagnostic, not a claim of tournament strength. The focused range-control change met its preregistered geometric metric; negative evidence and unresolved defects are discussed in the report. No external submission was made.
