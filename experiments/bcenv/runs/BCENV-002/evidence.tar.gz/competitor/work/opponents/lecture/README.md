# Official educational opponent provenance

Offline source catalog entry: sources/catalog.json (only season2023 entry).
Upstream repository: https://github.com/battlecode/battlecode23-lectureplayer
Pinned commit: 57063ad07b2311c21c99ba7be100a55fcdb3de6b
Upstream commit time supplied by catalog: 2023-01-20T02:46:15Z
Java package: lectureplayer; source root src/lectureplayer.
License: upstream GNU Affero General Public License v3 (AGPL-3.0), preserved verbatim in LICENSE. No repository-wide engine licensing claim is made. The opponent is separate from our independently written mybot source and source package.

Retrieval: Python zipfile read the supplied sources/battlecode23-lectureplayer.zip, matched every catalog path, checked archive SHA256 1a5589f3630ca103831be34d2b6cd4d22684c5e7222aa2353d603cda2b53ae9b and each of six Java files plus LICENSE against the catalog. Only Java went into the build source root. provenance.json preserves the exact catalog entry and all expected file hashes. Upstream scripts/wrappers were not run. Official BC23 javac/verifier built work/opponent-build with source aggregate hash f824855a89f50784b5c848ee559232d4405789788ddda92317b3b419257bc694 and binary aggregate 2ec96f458fb2cb6219efb33da246dd0d6f3da610693ac60d440fedc95ad2c008.

Authenticity is grounded in the supplied frozen official-source mirror and its hashes. This is reproducible local discovery and integration, not independent authentication of a live Git server, a signed-commit verification, or unaided Internet discovery. No network request or installation occurred. Source was inspected for entry point/build integration and opponent behavior; no implementation was copied into mybot. The opponent was not modified. Its verified artifact was active in every game; inert fixtures were not built or used.
