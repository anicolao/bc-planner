# Local BC23 active-opponent diagnostic

Read manifest.json, trial.json, both skills and docs/BC23-LOCAL.md. These are the
complete instructions for this local diagnostic, not the full replica trial.
Find the authentic lecture opponent using sources/. Read packaged rules/API in
reference/. Write your own candidate under competitor/src/ and all records,
retrieved opponent source and tool outputs under work/. Do not change other files.

Run ../../bcenv from this workspace. It presents this directory as /workspace in
a minimal credential-free runtime. Pass relative source/output paths. Maps live
at /opt/battlecode23/maps/ inside that runtime. Use the two maps in trial.json.

    ../../bcenv build --source competitor/src --package mybot --output work/build-001
    ../../bcenv run --team-a work/build-001 --team-b work/opponent-build --map /opt/battlecode23/maps/DefaultMap.map23 --output work/match-001
    ../../bcenv package --build work/build-001 --output work/package-001

Source inputs are Java-only package-relative directories. Every output must be
new. Read replay/query semantics in docs before interpreting evidence. No installs
or network calls are needed. No replica or submission endpoint is available.
General host tools are behaviorally restricted, not security-isolated. The runtime
has no inherited credentials or host filesystem binds. Stop on environment failure.
