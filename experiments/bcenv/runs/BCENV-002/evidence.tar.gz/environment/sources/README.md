# Frozen official source catalog

This source-only mirror contains a Battlecode organization's official educational
opponent. Inspect catalog.json to identify its year, source provenance, package,
license and file/archive hashes. Retrieve a copy under work/opponents/ and build
it yourself. No precompiled opponent is supplied. Only Java files belong in a
bcenv build source root; preserve the license/provenance outside that root.
This mirror supports reproducible offline discovery, not live-web search.
