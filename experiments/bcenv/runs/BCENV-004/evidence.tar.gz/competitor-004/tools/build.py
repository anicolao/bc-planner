#!/usr/bin/env python3
"""Fixed public build/package helper; only this candidate workspace is input."""
import argparse
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent.parent
COMMAND = ['/workspace/scratch/1523a3f802eb/nix-canonical-root/nix-root',
           'run', 'path:/workspace/scratch/1523a3f802eb/vm-reassessment/source#bcenv', '--']
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--package', required=True)
p.add_argument('--output', required=True, help='New directory under work/')
a = p.parse_args()
out = (ROOT / a.output).resolve()
if not out.is_relative_to(ROOT / 'work') or out.exists():
    p.error('Output must be a new directory under work/')
raise SystemExit(subprocess.call(COMMAND + ['build', '--source', str(ROOT/'src'),
    '--package', a.package, '--output', str(out), '--timeout', '120']))
