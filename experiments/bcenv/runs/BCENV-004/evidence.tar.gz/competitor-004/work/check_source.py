from pathlib import Path
s=Path('src/tempest/RobotPlayer.java').read_text()
# Exhaustively check protocol encoding against every legal coordinate/state.
for x in range(60):
 for y in range(60):
  for state in range(3):
   v=1+x+60*y+(state<<12)
   n=(v&4095)-1
   assert (n%60,n//60)==(x,y)
   assert v>>12==state
   assert 0<v<65536
assert 19+35==54
assert 'rc.canBuildRobot(type,p)' in s
assert 'rc.canMove(d)' in s
assert 'rc.canCollectResource(well,-1)' in s
assert 'rc.canTransferResource(home,t,n)' in s
print('PASS 10800 location/state roundtrips; shared array partition; guarded action source checks')
