# State-transition tests independent of engine; mirror version 3 arbitration.
def chosen(local_state,local_seen,shared_state,shared_exists,now):
 return local_state if local_seen==now or not shared_exists else shared_state
assert chosen(0,10,1,True,20)==1 # old neutral cannot hide published ownership
assert chosen(1,10,0,True,20)==0 # old friendly cannot hide published loss
assert chosen(0,20,1,True,20)==0 # fresh view is authoritative
assert chosen(0,10,0,False,20)==0 # unpublished discovery remains useful
print('PASS four stale/fresh island arbitration cases')
