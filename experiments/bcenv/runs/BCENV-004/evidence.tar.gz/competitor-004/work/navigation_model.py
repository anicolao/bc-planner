"""Independent grid model of v2 navigation score, NOT an engine simulation."""
import random
D=[(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1)]
def nav(start,target,blocked,rounds=400):
 rng=random.Random(7);p=start;visit={};trail=[]
 for turn in range(1,rounds+1):
  trail.append(p);visit[p]=turn
  if sum((a-b)**2 for a,b in zip(p,target))<=2:return turn,trail
  candidates=[]
  for dx,dy in D:
   q=p[0]+dx,p[1]+dy
   if not (0<=q[0]<30 and 0<=q[1]<30) or q in blocked:continue
   ago=turn-visit.get(q,0)
   score=4*sum((a-b)**2 for a,b in zip(q,target))+(8-ago)*12*(ago<8)+rng.randrange(3)
   candidates.append((score,q))
  if candidates:p=min(candidates)[1]
 return None,trail
cases={
 'open':((1,1),(27,27),set()),
 'wall':((4,15),(25,15),{(15,y) for y in range(25)}),
 'U_escape':((15,15),(28,15),{(20,y) for y in range(5,25)}|{(x,5) for x in range(8,21)}|{(x,24) for x in range(8,21)})}
for name,args in cases.items():
 result,trail=nav(*args)
 print(name,'reached_in',result,'final',trail[-1],'unique_positions',len(set(trail)))
