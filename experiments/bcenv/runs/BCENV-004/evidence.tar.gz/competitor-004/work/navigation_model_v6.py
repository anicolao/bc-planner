"""Independent v3 policy model, no engine behavior claimed."""
from navigation_model import cases,D
import random
def nav3(start,target,blocked,rounds=400):
 rng=random.Random(7);p=start;visit={};trail=[];best=10**9;stall=0;wall=False;wallDir=0;hit=0;steps=0
 def legal(q):return 0<=q[0]<30 and 0<=q[1]<30 and q not in blocked
 def dist(q):return sum((a-b)**2 for a,b in zip(q,target))
 for turn in range(1,rounds+1):
  trail.append(p);visit[p]=turn;nd=dist(p)
  if nd<=2:return turn,trail
  direct=D.index(((target[0]>p[0])-(target[0]<p[0]),(target[1]>p[1])-(target[1]<p[1])))
  if nd<best:best=nd;stall=0
  else:stall+=1
  if not wall and stall>=20:wall=True;wallDir=direct;hit=nd;steps=0
  if wall and nd<hit and legal((p[0]+D[direct][0],p[1]+D[direct][1])):wall=False;stall=0
  choice=None
  if wall:
   for i in range(8):
    d=(wallDir-i)%8;dx,dy=D[d];q=p[0]+dx,p[1]+dy
    if legal(q):choice=q;wallDir=(d+2)%8;break
   steps+=1
   if steps>90:wall=False;stall=0;best=10**9
  else:
   candidates=[]
   for dx,dy in D:
    q=p[0]+dx,p[1]+dy
    if not legal(q):continue
    ago=turn-visit.get(q,0)
    score=4*dist(q)+(8-ago)*12*(ago<8)+rng.randrange(3)
    candidates.append((score,q))
   if candidates:choice=min(candidates)[1]
  if choice:p=choice
 return None,trail
for name,args in cases.items():
 result,trail=nav3(*args);print('V6',name,'reached_in',result,'final',trail[-1],'unique_positions',len(set(trail)));assert result is not None
