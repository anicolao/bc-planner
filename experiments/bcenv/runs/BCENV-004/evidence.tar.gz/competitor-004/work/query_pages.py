import subprocess,json,sys,pathlib
submission,game,start,end,tag=sys.argv[1:6]
robot=sys.argv[6] if len(sys.argv)>6 else None
offset=0
for page in range(16):
 cmd=['python3','tools/service.py','--mailbox','mailbox','replay','--submission',submission,'--game',game,'--start',start,'--end',end,'--offset',str(offset),'--limit','128']
 if robot:cmd+=['--robot',robot]
 p=subprocess.run(cmd,text=True,capture_output=True)
 path=pathlib.Path('work')/f'{tag}-p{page}.json';path.write_text(p.stdout)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 j=json.loads(p.stdout)
 if j.get('status')!='replay':raise RuntimeError(j)
 f=j['feedback'];c=f['coverage'];r=f['records']
 print(path,'returned',len(r),'offset',offset,'more',c['has_more'],'truncated',c['truncation_reasons'])
 for v in r:
  if v.get('team_slot')=='own' and v['kind']=='action':print('  ',v['round'],v['robot_id'],v['body_type'],v['action'],v['raw_target'])
 if not c['has_more']:break
 nxt=c['next_record_offset']
 assert nxt>offset
 offset=nxt
else:raise RuntimeError('pagination cap reached; interval incomplete')
