# Exhaustively check the v4 eligibility gate cannot spend below an active reserve.
for reserve in (0,80):
 for ad in range(201):
  for mana in range(201):
   launcher=mana>=45+reserve
   carrier=not launcher and ad>=50+reserve
   if launcher:assert mana-45>=reserve
   if carrier:assert ad-50>=reserve
print('PASS 80802 resource-state reservation cases')
