
package USQualifiers;

import battlecode.common.RobotController;

public class Destabilizer {
    public static void run(RobotController rc) {

    }
}
